//
//  CygnusUI.h
//  CygnusUI
//
//  Created by Conner Christianson on 1/17/24.
//

#import <UIKit/UIKit.h>

//! Project version number for UI.
FOUNDATION_EXPORT double UIVersionNumber;

//! Project version string for UI.
FOUNDATION_EXPORT const unsigned char UIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UI/PublicHeader.h>


